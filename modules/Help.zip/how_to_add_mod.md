
Each ebook module is packaged as a `.zip` file. To view these files perform the following steps:

| Steps | Instructions                                                            |
| :---: | :---------------------------------------------------------------------- |
|  1.   | Open the folder where this app resides                                  |
|  2.   | From there, save the ebook file (`.zip` file) into the `modules` folder |
|  3.   | Close this app and reopen it to see the new content added               |