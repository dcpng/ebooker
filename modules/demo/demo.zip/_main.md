# Here are the steps for Openning a folder in VS Code

`{'mod':'speak'}` These are the steps

1. `{'mod':'speak'}` Factorise out the x squared (`{'mod':'math','eq':'x^2'}`) 
```{'mod':'math'}
{x^2+kx^2}/x^2 => {(1+k)x^2}/x^2
```

2. `{'mod':'speak'}` The `{'mod':'math','eq':'x^2'}` cancels out

```{'mod':'math'}
{(1+k)x^2}/x^2 => {(1+k)cancel(x^2)}/cancel(x^2) => {1+k}/1 => 1+k
```

# Chemistry equations

```{'mod':'math'}
2H_2O + O_2 + 2e^{-} => 2H_2 + 2O_2
```
|           molecule            |   name   |
| :---------------------------: | :------: |
| (`{'mod':'math','eq':'2H_2O'}`) |  Water   |
| (`{'mod':'math','eq':'2O'}`)   |  Oxygen  |
| (`{'mod':'math','eq':'e-'}`)   | electron |